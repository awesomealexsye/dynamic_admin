<?php
session_start();
define('APP_NAME','Dynamic Panel');
define('APP_PATH',__DIR__);
define('APP_URL','http://localhost:8000/');
define('DEV_CODE','arbaz@123');
define('DB_HOST','localhost');
define('DB_USER','awesome');
define('DB_PASS','awesome@123');
define('DB_NAME','dynamic_admin');


